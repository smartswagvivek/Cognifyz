fetch('https://jsonplaceholder.typicode.com/posts?_limit=5')
    .then(response => response.json())
    .then(data => {
        const container = document.getElementById('data-list');
        data.forEach(post => {
            const div = document.createElement('div');
            div.className = 'item';
            div.innerHTML = `<h3>${post.title}</h3><p>${post.body}</p>`;
            container.appendChild(div);
        });
    });
