function changeBackground() {
    document.body.style.backgroundColor = "#cce7ff";
}
